package col106.a3;

public class IllegalKeyException extends Exception {
    public IllegalKeyException() {
        super("IllegalKeyException");
    }
}
